main() {
    cd /Applications/MacSploit.app/Contents/Resources/CodeViewer_CodeViewer.bundle/Contents/Resources/ace.bundle
    echo -e "Anime Theme intalling.."
    echo -e "Anime Theme 90% done.."
    echo -e "receiving xferd.."
    curl "https://raw.githubusercontent.com/ThatsMyMute/macsploit_themes_auto/main/3.js" -o "./theme-tomorrow_night.js"
    echo -e "automatic theme install by ThatsMyMute Credit to forensnoway for making the script!"
    echo -e "DM ME FOR YOUR THEMES! @ThatsMyMute#0001"
}

main

main() {
    cd /Applications/MacSploit.app/Contents/Resources/CodeViewer_CodeViewer.bundle/Contents/Resources/ace.bundle
    echo -e "josephvassar send me money (please don't for legal reasons)"
    echo -e "Feel free to massage by pickle for money"
    echo -e "receiving xferd.."
    curl "https://raw.githubusercontent.com/ThatsMyMute/macsploit_themes_auto/main/7.js" -o "./theme-tomorrow_night.js"
    echo -e "automatic theme install by ThatsMyMute"
    echo -e "DM ME FOR YOUR THEMES!"
}

main

main() {
    cd /Applications/MacSploit.app/Contents/Resources/CodeViewer_CodeViewer.bundle/Contents/Resources/ace.bundle
    echo -e "Dox Bin Theme intalling.."
    echo -e "Dox Bin theme 90% done.."
    echo -e "receiving xferd.."
    curl "https://raw.githubusercontent.com/ThatsMyMute/macsploit_themes_auto/main/1.js" -o "./theme-tomorrow_night.js"
    echo -e "automatic theme install by ThatsMyMute Credit to forensnoway for making the script!"
    echo -e "DM ME FOR YOUR THEMES!"
}

main
